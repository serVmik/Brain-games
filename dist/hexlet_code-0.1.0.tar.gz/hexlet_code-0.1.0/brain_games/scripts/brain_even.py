#!/usr/bin/env python3
# file:brain_even.py
import brain_games.game_logics


def main():
    name_of_game = 'brain_even'
    brain_games.game_logics.begin_to_game(name_of_game)


if __name__ == '__main__':
    main()
