### Hexlet tests and linter status:
[![Actions Status](https://github.com/serVmik/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/serVmik/python-project-49/actions)

How to install the brain-games: https://asciinema.org/a/XmBG1NT0RfFCQStuJQDmYwJKm

Game "Parity check"
How to start the game: https://asciinema.org/a/jBwDXnNncGL78oj0ffy6eSpPs
Starting the game with a win: https://asciinema.org/a/lVXRmopOkIyG0MscYx4RxCiSl
Start the game with defeat: https://asciinema.org/a/11Mx4QhsxSkuUXai8X7jQrRAX

Game "Calculator"
How to run the game: https://asciinema.org/a/oPj4pTA41Q8vNsunFJRliE4pV
Starting the game with a win: https://asciinema.org/a/cTVtMNNw4pJOST7ksNtc6tKsS
Start the game with defeat: https://asciinema.org/a/pDegDjk1VOZn0xm9R3dKS8w1G
