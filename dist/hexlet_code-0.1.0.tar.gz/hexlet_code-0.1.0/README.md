### Hexlet tests and linter status:
[![Actions Status](https://github.com/serVmik/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/serVmik/python-project-49/actions)


how to install the brain-games: https://asciinema.org/a/XmBG1NT0RfFCQStuJQDmYwJKm
how to start the brain-games: https://asciinema.org/a/jBwDXnNncGL78oj0ffy6eSpPs
starting the game with a win: https://asciinema.org/a/lVXRmopOkIyG0MscYx4RxCiSl
start the game with defeat: https://asciinema.org/a/11Mx4QhsxSkuUXai8X7jQrRAX
